USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spUpdateModule
(
@moduleCode VARCHAR(50),
@moduleName VARCHAR(50),
@moduleDescription VARCHAR(60),
@moduleResourceLink VARCHAR(70)
)
AS
BEGIN
UPDATE Module
SET		moduleCode = @moduleCode,
		moduleName = @moduleName,
		moduleDescription = @moduleDescription,
		moduleResourceLink = @moduleResourceLink
                    
WHERE moduleCode = @moduleCode
						
END