USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spSearchModule
(
@moduleCode VARCHAR
)
AS
BEGIN
SELECT*
FROM Module
WHERE moduleCode = @moduleCode

END

