USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spDeleteModule
(
@moduleCode VARCHAR
)
AS
BEGIN
DELETE FROM Module
WHERE moduleCode = @moduleCode
END