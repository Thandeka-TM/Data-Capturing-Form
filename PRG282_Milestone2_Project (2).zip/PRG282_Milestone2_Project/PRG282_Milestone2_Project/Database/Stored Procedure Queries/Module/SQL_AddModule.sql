USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spAddModule
(
@moduleCode VARCHAR(50),
@moduleName VARCHAR(50),
@moduleDescription VARCHAR(60),
@moduleResourceLink VARCHAR(70)
)
AS
BEGIN
INSERT INTO Module
VALUES(@moduleCode,@moduleName,@moduleDescription,@moduleResourceLink)

END