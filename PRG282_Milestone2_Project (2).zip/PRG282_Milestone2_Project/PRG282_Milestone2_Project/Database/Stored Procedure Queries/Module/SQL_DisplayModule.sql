USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spGetModule
AS
BEGIN
SELECT*
FROM Module
END

EXECUTE spGetModule