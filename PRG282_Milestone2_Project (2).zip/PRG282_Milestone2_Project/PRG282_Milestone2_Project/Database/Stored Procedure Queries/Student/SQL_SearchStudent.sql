USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spSearchStudent
(
@studentNumber INT
)
AS
BEGIN
SELECT*
FROM Students
WHERE studentNumber = @studentNumber

END