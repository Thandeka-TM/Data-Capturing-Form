USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spDeleteStudent
(
@studentNumber INT
)
AS
BEGIN
DELETE FROM Students
WHERE studentNumber = @studentNumber
END