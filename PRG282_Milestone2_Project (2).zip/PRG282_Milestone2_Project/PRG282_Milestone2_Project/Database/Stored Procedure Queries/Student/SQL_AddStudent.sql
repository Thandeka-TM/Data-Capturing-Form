USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spAddStudent
(
@studentNumber INT,
@studentName VARCHAR(50),
@studentSurname VARCHAR(50),
@studentImage VARCHAR(80),
@studentDOB DATE,
@gender VARCHAR(30),
@phone VARCHAR(20),
@studentAddress VARCHAR(50),
@studentModuleCodes VARCHAR(50)
)
AS
BEGIN
INSERT INTO Students
VALUES(@studentNumber,@studentName,@studentSurname,@studentImage,@studentDOB,@gender,@phone,@studentAddress,@studentModuleCodes)

END