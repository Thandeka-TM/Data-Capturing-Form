USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spUpdateStudent
(
@studentNumber INT,
@studentName VARCHAR(50),
@studentSurname VARCHAR(50),
@studentImage VARCHAR(80),
@studentDOB DATE,
@gender VARCHAR(30),
@phone VARCHAR(20),
@studentAddress VARCHAR(50),
@studentModuleCodes VARCHAR(50)
)
AS
BEGIN
UPDATE Students
SET		studentNumber = @studentNumber,
		studentName = @studentName,
		studentSurname = @studentSurname,
		studentImage = @studentImage,
		studentDOB = @studentDOB,
		gender = @gender,
		phone = @phone,
		studentAddress = @studentAddress,
		studentModuleCodes = @studentModuleCodes
                    
WHERE studentNumber = @studentNumber
						
END