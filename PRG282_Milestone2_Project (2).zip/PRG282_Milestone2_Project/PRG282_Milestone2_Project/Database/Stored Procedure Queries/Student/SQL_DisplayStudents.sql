USE BelgiumCampusDatabase;
GO
CREATE PROCEDURE spGetStudents
AS
BEGIN
SELECT*
FROM Students
END

EXECUTE spGetStudents