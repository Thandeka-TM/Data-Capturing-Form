﻿using PRG282_Milestone2_Project.DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282_Milestone2_Project.BusinessLogicLayer;
using PRG282_Milestone2_Project.PresentationLayer;
using System.IO;


namespace PRG282_Milestone2_Project
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        //DataTable dt = new DataTable();
        User_FileHandler fh = new User_FileHandler();

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                fh.LoginUserValidation(txtUsername.Text, txtPassword.Text);                
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message);
            }
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            try
            {
                fh.SignUpUser(txtUsername.Text, txtPassword.Text);
                MessageBox.Show("User successfully added");
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message);
            }
        }
    }
}
